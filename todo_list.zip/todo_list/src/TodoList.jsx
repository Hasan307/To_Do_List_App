
import React, { useState } from 'react';
import './TodoList.css'; // Import the CSS file for TodoList

const TodoList = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');

  const handleTaskChange = (e) => {
    setNewTask(e.target.value);
  };

  const handleAddTask = () => {
    if (newTask.trim() === '') return;
    setTasks([...tasks, { description: newTask, completed: false }]);
    setNewTask('');
  };

  const handleDeleteTask = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks.splice(index, 1);
    setTasks(updatedTasks);
  };

  const handleToggleComplete = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].completed = !updatedTasks[index].completed;
    setTasks(updatedTasks);
  };

  return (
    <div className="todo-container">
      <h1>To-Do List</h1>
      <div className="add-task-container">
        <input type="text" value={newTask} onChange={handleTaskChange} />
        <button onClick={handleAddTask}>Add Task</button>
      </div>
      <ul className="task-list">
        <li className="task-list-heading">
          <span>Task Description</span>
          <span>Status</span>
          <span>Remove</span>
        </li>
        {tasks.map((task, index) => (
          <li key={index} className="task-item">
            <span
              className={`task-description ${task.completed ? 'completed' : ''}`}
            >
              {task.description}
            </span>
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => handleToggleComplete(index)}
            />
            <button onClick={() => handleDeleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
