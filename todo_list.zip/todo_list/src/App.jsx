import React from 'react';
import TodoList from './TodoList';
import './App.css'; // Import the CSS file

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
